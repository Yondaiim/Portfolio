# TODOLISTE

# Page d'accueil (Toute les todos)
# (Fomulaire (titre de la todo, ainsi contenu), (status par défault à non complété))
# Sur chaque Todo (Passer le status a complété ou non completé)
# Possibilite de supprimer un todo
# Base Donnée MongoDB

[] GET / ( Toutes les todos)
[] POST / (Ajouter une todo) (status : false, par défaut)
[] POST /delete/:todoId (Supprimer une todo)