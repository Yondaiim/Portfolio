<?php
require_once "admin/Admin.php";
Admin::createAdmin();
$title = "Bienvenue sur EMQUIZZ !";
$style = "index.css";
require_once "views/partials/header.php";
?>

<header>
  <div class="topprincipal">
    <div class="headergauche">
      <img src="/public/images/emsca.png" alt="Logo" class="emsca">
    </div>
    <form class="headerdroit" action="/admin/connexion.php" >
      <input class="connexion" type="text" placeholder="Identifiant">
      <input class="connexion" type="password" placeholder="Mot de passe">
      <button class="accesadmin" type="submit">Entrer</button>
</form>
  </div>
</header>

<div class="main_page" id="main_page">
    <div class="title">
      <h1>Bienvenue sur EMQUIZZ !</h1>
    </div>
    <div class="Bouton">
        <button type="button" class="play-button">
            <a href="/views/quizz/categorie.php">Commençons un Quizz !</a>
        </button>
    </div>
  </div>
</div>

<?php require_once "views/partials/footer.php";?>