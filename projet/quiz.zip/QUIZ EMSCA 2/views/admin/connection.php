<?php
       if(isset($_POST["pseudo"]) && isset($_POST["password"]  )) {
                var_dump($_POST);
       } 
?>

