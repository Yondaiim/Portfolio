<?php
$title = "Voici votre résultat !";
$style = "resultat.css";
require_once "../partials/header.php";

?>
<?php session_unset() ?>
<div class="resultat" id="resultat">
    <div class="carreblanc">
        <h4>Merci de votre participation !</h4>
        <div class="annonce_resultat">
            <p>Votre résultat est de ...</p>
            <h5></h5>
        </div> 
    </div>
    <button class="continuer">
        <a href="/index.php">Revenir à l'accueil</a>
    </button>
</div>

<script>

    const counter = localStorage.getItem('counter')
    const resultHTML = document.querySelector(".annonce_resultat h5")
    resultHTML.textContent = counter || 0
    localStorage.removeItem("counter")
</script>   