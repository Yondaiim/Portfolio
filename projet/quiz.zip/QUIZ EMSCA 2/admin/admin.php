<?php

class Admin{
    public static function createAdmin(){
        require_once "database/connection.php";
        //*** Verifier si on a un administrateur;
        $pdo = Database::db_connect();
        $stmt = $pdo->query("SELECT * FROM administrateurs");
        $result = $stmt->fetchAll();
        if(count($result) > 0)return;
        //require_once "database/config.php";
        $admin_pseudo = "admin";
        $admin_mdp = "admin";
        $password = password_hash($admin_mdp, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO administrateurs(pseudo, mot_de_passe) VALUES (?,?)");
        $stmt->execute([$admin_pseudo, $password]);
    }
}

?>