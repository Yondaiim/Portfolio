<?php

class Database{
    private static $instance = null;
static function db_connect(){
    require_once("config.php");
    try {
        if (self::$instance === null) {
            self::$instance = new PDO("mysql:host=$host;dbname=$dbname", $username, $pwd);
            self::$instance-> setAttribute(PDO :: ATTR_ERRMODE, PDO ::ERRMODE_EXCEPTION);
            self::$instance-> setAttribute(PDO :: ATTR_DEFAULT_FETCH_MODE, PDO ::FETCH_ASSOC);
        return self::$instance;
        }
    
    } catch (PDOException $ex) {
        echo $ex ->getMessage();
    }
    

    }
}
