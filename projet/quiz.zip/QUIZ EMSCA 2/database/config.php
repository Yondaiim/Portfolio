<?php
$host = "localhost";
$dbname = "emsquiz";
$username = "root";
$pwd = "Gallas77!";
$admin_pseudo = "admin";
$admin_mdp = "admin";
?>
